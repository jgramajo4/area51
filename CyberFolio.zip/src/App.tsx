import { useState, useEffect } from 'react'
import Terminal from './components/Terminal'
import CommandLine from './components/CommandLine'
import { CommandResponse } from './components/CommandResponse'
import { processCommand } from './utils/commands'
import './index.css'

function App() {
  const [history, setHistory] = useState<Array<{command: string, response: JSX.Element}>>([])
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    if (!isInitialized) {
      const initialResponse = processCommand('help')
      setHistory([{ command: 'help', response: initialResponse }])
      setIsInitialized(true)
    }
  }, [isInitialized])

  const handleCommand = (command: string) => {
    const response = processCommand(command)
    setHistory([...history, { command, response }])
  }

  return (
    <div className="min-h-screen bg-black text-green-500 p-4 font-mono">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-green-500/5 border border-green-500/20" style={{ transform: 'translate(4px, 4px)' }}></div>
            <div className="relative p-4 bg-black border border-green-500 shadow-lg">
              <h1 className="text-3xl font-bold tracking-[0.2em] text-center mb-2 title-glow">
                AREA51 TERMINAL
              </h1>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="px-3 py-1 border border-green-500/50 bg-green-500/10">
                  <span className="text-green-400">STATUS:</span> ACTIVE
                </div>
                <div className="px-3 py-1 border border-green-500/50 bg-green-500/10">
                  <span className="text-green-400">CLEARANCE:</span> ALPHA-1
                </div>
              </div>
            </div>
          </div>
        </header>
        
        <Terminal>
          {history.map((entry, index) => (
            <div key={index} className="mb-4">
              <div className="flex items-center gap-2">
                <span className="text-green-500">$</span>
                <span>{entry.command}</span>
              </div>
              <CommandResponse>{entry.response}</CommandResponse>
            </div>
          ))}
          <CommandLine onCommand={handleCommand} />
        </Terminal>

        <footer className="mt-6 text-center text-xs text-green-500/50">
          AREA51 Terminal v1.0 • Authorized Access Only
        </footer>
      </div>
    </div>
  )
}

export default App

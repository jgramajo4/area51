import { Links } from '../components/Links'

export const processCommand = (command: string): JSX.Element => {
  const commands = {
    'help': (
      <div>
        <p className="mb-2">Available commands:</p>
        <ul className="list-disc ml-4">
          <li>help - Show this help message</li>
          <li>about - Display information about this terminal</li>
          <li>links - View important links</li>
          <li>clear - Clear terminal history</li>
        </ul>
      </div>
    ),
    'about': (
      <div className="space-y-4">
        <div>
          <p className="mb-2 text-green-400 font-bold">TOP SECRET TERMINAL v1.0</p>
          <p>Authorized access only. This terminal contains classified information.</p>
          <p>Clearance level ALPHA-1 required for full access.</p>
        </div>
        <div className="border-l-2 border-green-500 pl-4 italic">
          <p>Area isn't just a place – it's a launchpad for the unseen. Where the impossible becomes inevitable. Belief is our fuel and innovation our starship. Charting the uncharted, one block at a time.</p>
        </div>
      </div>
    ),
    'links': <Links />,
    'clear': (
      <div>
        <p>Terminal cleared.</p>
      </div>
    )
  }

  const commandKey = command.toLowerCase() as keyof typeof commands
  return commands[commandKey] || <p>Command not recognized. Type 'help' for available commands.</p>
}

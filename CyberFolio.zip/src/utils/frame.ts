export interface FrameState {
  page: 'home' | 'terminal' | 'links' | 'about';
  version: number;
}

export interface FrameResponse {
  version: 'vNext';
  image: string;
  buttons: string[];
  post_url: string;
}

export const generateFrameMetadata = (state: FrameState): FrameResponse => {
  const baseUrl = 'https://your-domain.com';

  let image = `${baseUrl}/sarea-logo.png`;
  let buttons: string[] = [];

  switch (state.page) {
    case 'home':
      buttons = ['Enter Terminal', 'View Links', 'About SAREA'];
      break;
    case 'terminal':
      buttons = ['Help', 'Clear', 'Back'];
      image = `${baseUrl}/terminal-preview.png`;
      break;
    case 'links':
      buttons = ['Telegram', 'Dexscreener', 'Back'];
      image = `${baseUrl}/links-preview.png`;
      break;
    case 'about':
      buttons = ['Back to Home'];
      image = `${baseUrl}/about-preview.png`;
      break;
  }

  return {
    version: 'vNext',
    image,
    buttons,
    post_url: `${baseUrl}/api/frame`
  };
};

export const validateFrameRequest = (requestData: any): boolean => {
  // Implement frame message validation as per specs
  // https://docs.farcaster.xyz/developers/frames/v2/spec#frame-message-validation
  const requiredFields = ['untrustedData', 'trustedData'];
  return requiredFields.every(field => field in requestData);
};

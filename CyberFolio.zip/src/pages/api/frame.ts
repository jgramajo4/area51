import { validateFrameRequest, generateFrameMetadata, FrameState } from '../../utils/frame';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Validate the frame request
  if (!validateFrameRequest(req.body)) {
    return res.status(400).json({ error: 'Invalid frame request' });
  }

  // Parse button index (1-based) from the request
  const buttonIndex = req.body?.untrustedData?.buttonIndex;
  const currentState: FrameState = {
    page: 'home',
    version: 1,
  };

  // Update state based on button clicked
  if (buttonIndex === 1) {
    currentState.page = 'terminal';
  } else if (buttonIndex === 2) {
    currentState.page = 'links';
  } else if (buttonIndex === 3) {
    currentState.page = 'about';
  }

  // Generate frame metadata based on new state
  const frameMetadata = generateFrameMetadata(currentState);

  // Set the appropriate headers
  res.setHeader('Content-Type', 'text/html');
  
  // Return the frame response
  return res.status(200).send(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta property="fc:frame" content="vNext" />
        <meta property="fc:frame:image" content="${frameMetadata.image}" />
        ${frameMetadata.buttons.map((button, i) => 
          `<meta property="fc:frame:button:${i + 1}" content="${button}" />`
        ).join('\n')}
        <meta property="fc:frame:post_url" content="${frameMetadata.post_url}" />
      </head>
    </html>
  `);
}

import { ReactNode } from 'react'

interface CommandResponseProps {
  children: ReactNode
}

export const CommandResponse: React.FC<CommandResponseProps> = ({ children }) => {
  return (
    <div className="mt-2 ml-4">
      {children}
    </div>
  )
}

import { ExternalLink } from 'lucide-react'

export const Links = () => {
  const links = [
    {
      title: 'Telegram Channel',
      url: 'https://t.me/aliencollective',
      description: 'Join the Alien Collective'
    },
    {
      title: 'Dexscreener',
      url: 'https://t.me/aliencollective',
      description: 'Track token metrics'
    },
    {
      title: 'Area51 Channel',
      url: 'https://warpcast.com/~/channel/area51',
      description: 'Secret communications hub'
    },
    {
      title: 'Buy On Matcha',
      url: 'https://matcha.xyz/tokens/base/0x15130ae3f159134bb7ba2d0f17e55dcc155aec76',
      description: 'Secure token acquisition'
    }
  ]

  return (
    <div className="space-y-4">
      <div className="border-b border-green-500 pb-2">
        <p className="text-lg font-bold tracking-wider">ENCRYPTED NETWORK LINKS</p>
        <p className="text-sm opacity-70">ACCESS LEVEL: AUTHORIZED</p>
      </div>
      
      <div className="grid gap-3">
        {links.map((link, index) => (
          <div
            key={index}
            className="border border-green-500/30 bg-green-900/10 p-3 hover:bg-green-900/20 transition-all"
          >
            <a
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between group"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-green-400 font-semibold">{link.title}</span>
                  <ExternalLink size={14} className="opacity-50 group-hover:opacity-100 transition-opacity" />
                </div>
                <p className="text-sm text-green-500/70">{link.description}</p>
              </div>
              <div className="text-xs opacity-50 group-hover:opacity-100 transition-opacity">
                [SECURED]
              </div>
            </a>
          </div>
        ))}
      </div>
    </div>
  )
}

interface TerminalProps {
  children: React.ReactNode
}

const Terminal: React.FC<TerminalProps> = ({ children }) => {
  return (
    <div className="bg-black border border-green-500 p-4 rounded-sm font-mono text-sm overflow-y-auto max-h-[80vh]">
      {children}
    </div>
  )
}

export default Terminal

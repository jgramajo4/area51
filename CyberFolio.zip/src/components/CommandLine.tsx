import { useState, useEffect, useRef } from 'react'
import { processCommand } from '../utils/commands'

interface CommandLineProps {
  onCommand: (command: string) => void
}

const CommandLine: React.FC<CommandLineProps> = ({ onCommand }) => {
  const [input, setInput] = useState('')
  const [preview, setPreview] = useState<JSX.Element | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  // Update preview as user types
  useEffect(() => {
    if (input.trim()) {
      const response = processCommand(input.trim().toLowerCase())
      setPreview(
        <div className="mt-2 ml-6 opacity-50">
          <div className="text-xs text-green-500/50 mb-1">[Preview]</div>
          {response}
        </div>
      )
    } else {
      setPreview(null)
    }
  }, [input])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      onCommand(input.trim().toLowerCase())
      setInput('')
      setPreview(null)
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <span className="text-green-500">$</span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent border-none outline-none text-green-500 font-mono"
          autoFocus
        />
        <span className="animate-pulse">█</span>
      </form>
      {preview}
    </div>
  )
}

export default CommandLine

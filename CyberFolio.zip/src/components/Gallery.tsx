import { useState, useEffect } from 'react'
import { Upload, X } from 'lucide-react'

export const Gallery = () => {
  const [images, setImages] = useState<string[]>([])

  useEffect(() => {
    const savedImages = localStorage.getItem('gallery-images')
    if (savedImages) {
      setImages(JSON.parse(savedImages))
    }
  }, [])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader()
        reader.onloadend = () => {
          const newImages = [...images, reader.result as string]
          setImages(newImages)
          localStorage.setItem('gallery-images', JSON.stringify(newImages))
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index)
    setImages(newImages)
    localStorage.setItem('gallery-images', JSON.stringify(newImages))
  }

  return (
    <div>
      <div className="mb-4">
        <label className="flex items-center gap-2 cursor-pointer hover:text-green-400">
          <Upload size={16} />
          <span>Upload Image</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            multiple
          />
        </label>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {images.map((image, index) => (
          <div key={index} className="relative group">
            <img
              src={image}
              alt={`Upload ${index + 1}`}
              className="w-full h-40 object-cover border border-green-500"
            />
            <button
              onClick={() => removeImage(index)}
              className="absolute top-2 right-2 p-1 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

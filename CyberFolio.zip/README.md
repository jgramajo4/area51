# Cyber Terminal

A cyberpunk-themed terminal interface application.

## Deployment

This application can be easily deployed using Vercel. Follow these steps:

1. First, create a [Vercel account](https://vercel.com/signup) if you don't have one

2. Install Vercel CLI globally:
```bash
npm install -g vercel
```

3. From your project directory, deploy using one of these methods:

### Method 1: Using Vercel CLI
```bash
vercel
```
Follow the prompts to deploy your application.

### Method 2: Using Vercel Dashboard

1. Push your code to a GitHub repository
2. Go to [Vercel Dashboard](https://vercel.com/dashboard)
3. Click "New Project"
4. Import your GitHub repository
5. Keep the default settings (Vite will be auto-detected)
6. Click "Deploy"

Your application will be automatically built and deployed. Vercel will provide you with a production URL where your app is live.

## Development

To run the project locally:

```bash
npm install
npm run dev
```

## Build

To create a production build:

```bash
npm run build
```
